<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="number"],
        button, 
        input[type="submit"] {
            margin-bottom: 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }
        input[type="submit"], button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover, button:hover {
            background-color: #0056b3;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: center;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Enroll Student</h1>
        <?php
        // Include the database connection
        require_once 'db_connect.php';

        // Check if the form is submitted
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data and sanitize it
            $firstName = $_POST['firstName'];
            $lastName = $_POST['lastName'];
            $address = $_POST['address'];
            $birthdate = $_POST['birthdate'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $programID = $_POST['programID'];

            try {
                // Prepare SQL query to insert a new student
                $sql = "INSERT INTO student (firstName, lastName, address, birthdate, email, phone, programID)
                        VALUES (:firstName, :lastName, :address, :birthdate, :email, :phone, :programID)";
                
                // Prepare the statement
                $stmt = $conn->prepare($sql);

                // Bind parameters to the SQL query
                $stmt->bindParam(':firstName', $firstName);
                $stmt->bindParam(':lastName', $lastName);
                $stmt->bindParam(':address', $address);
                $stmt->bindParam(':birthdate', $birthdate);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':phone', $phone);
                $stmt->bindParam(':programID', $programID);

                // Execute the query
                if ($stmt->execute()) {
                    echo '<div class="message success">Student enrolled successfully!</div>';
                } else {
                    echo '<div class="message error">Error enrolling student.</div>';
                }
            } catch (PDOException $e) {
                echo '<div class="message error">Error enrolling student: ' . $e->getMessage() . '</div>';
            }
        }
        ?>

        <!-- Enrollment form -->
        <form action="enroll_student.php" method="POST">
            <label for="firstName">First Name:</label>
            <input type="text" name="firstName" required>

            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" required>

            <label for="address">Address:</label>
            <input type="text" name="address" required>

            <label for="birthdate">Birthdate:</label>
            <input type="date" name="birthdate" required>

            <label for="email">Email:</label>
            <input type="email" name="email" required>

            <label for="phone">Phone:</label>
            <input type="text" name="phone" required>

            <label for="programID">Program ID:</label>
            <input type="number" name="programID" required>

            <input type="submit" value="Enroll Student">
        </form>

        <!-- Return to Admin Dashboard button -->
        <form action="admin_dashboard.php" method="GET">
            <button type="submit">Return to Admin Dashboard</button>
        </form>
    </div>
</body>
</html>
