DROP DATABASE CP3520;

-- Create database

CREATE DATABASE CP3520;
USE CP3520;

CREATE TABLE administrator (
    id INT PRIMARY KEY NOT NULL,
    adminName VARCHAR(64) NOT NULL,
    email VARCHAR(64) NOT NULL,
    phone VARCHAR(16) NOT NULL
);

-- Create entity tables and junction tables

CREATE TABLE student (
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    firstName VARCHAR(64) NOT NULL,
    lastName VARCHAR(64) NOT NULL,
    address VARCHAR(64) NOT NULL,
    birthdate DATE NOT NULL,
    email VARCHAR(64) NOT NULL,
    phone VARCHAR(16) NOT NULL,
    programID INT NOT NULL
);

CREATE TABLE program (
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    programName VARCHAR(64) NOT NULL,
    leadID INT
);

CREATE TABLE instructor (
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    instructorName VARCHAR(64) NOT NULL,
    address VARCHAR(64) NOT NULL,
    office INT,
    email VARCHAR(64) NOT NULL,
    phone VARCHAR(16) NOT NULL,
    programID INT
);

CREATE TABLE course (
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    courseName VARCHAR(64) NOT NULL,
    lecture INT NOT NULL,
    credit INT NOT NULL,
    labhours INT NOT NULL,
    semester INT NOT NULL
);

CREATE TABLE course_prerequisite (
    courseID INT NOT NULL,
    prerequisiteID INT NOT NULL,
    PRIMARY KEY (courseID, prerequisiteID),
    FOREIGN KEY (courseID) REFERENCES course(id),
    FOREIGN KEY (prerequisiteID) REFERENCES course(id)
);

CREATE TABLE grades (
    studentID INT NOT NULL,
    courseID INT NOT NULL,
    grade DECIMAL(5, 2),
    PRIMARY KEY (studentID, courseID),
    FOREIGN KEY (studentID) REFERENCES student(id),
    FOREIGN KEY (courseID) REFERENCES course(id)
);


CREATE TABLE teaches (
    instructorID INT NOT NULL,
    courseID INT NOT NULL,
    PRIMARY KEY (instructorID, courseID),
    FOREIGN KEY (instructorID) REFERENCES instructor(id),
    FOREIGN KEY (courseID) REFERENCES course(id)
);

CREATE TABLE enrollment (
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    studentID INT NOT NULL,
    programID INT NOT NULL,
    adminID INT NOT NULL,
    approved BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (studentID) REFERENCES student(id),
    FOREIGN KEY (programID) REFERENCES program(id),
    FOREIGN KEY (adminID) REFERENCES administrator(id)
);


-- Add foreign keys and setup auto increments

ALTER TABLE student
ADD CONSTRAINT fk_student_program FOREIGN KEY (programID) REFERENCES program(id),
auto_increment=20100000;

ALTER TABLE program
ADD CONSTRAINT fk_program_lead FOREIGN KEY (leadID) REFERENCES instructor(id),
auto_increment=1;

ALTER TABLE instructor
ADD CONSTRAINT fk_instructor_program FOREIGN KEY (programID) REFERENCES program(id),
auto_increment=10000000;

ALTER TABLE course
auto_increment=2000;

-- Populate tables

INSERT INTO administrator (id, adminName, email, phone) VALUES
(40000000, 'John Admin', 'johnadmin@iwp.ca', '1 (709) 123-4567');

INSERT INTO program (programName, leadID) VALUES
('Biomedical', NULL),
('Electrical', NULL);

INSERT INTO instructor (instructorName, address, office, email, phone, programID) VALUES
('John Biomedical', '123 Biomed Street', 328, 'johnbiomedical@isp.ca', '1 (709) 123-0987', 1),
('John Electrical', '345 Electric Street', 405, 'johnelectrical@isp.ca', '1 (709) 123-4304', 2),
('Gingle Doof', '48 Hardwun Road', NULL, 'gingledoof@isp.ca', '1 (709) 123-4619', NULL),
('Quandale Dingle', '19 The Crescent', NULL, 'quandaledingle@isp.ca', '1 (709) 123-4675', NULL);

INSERT INTO student (firstName, lastName, address, birthdate, email, phone, programID) VALUES
('Bobson', 'Dugnutt', '48 This Street', '2002-06-14', 'bobsondugnutt00@isp.ca', '1 (709) 123-7756', 1),
('Billy', 'Maizier', '10 That Street', '1999-11-03', 'billymaizier01@isp.ca', '1 (709) 123-9958', 1),
('John', 'Student', '89 Underthere Avenue', '2001-05-02', 'johnstudent02@isp.ca', '1 (709) 123-6929', 2),
('Quindarius', 'Doof', '48 Hardwun Road', '2004-06-07', 'quindariusdoof03@isp.ca', '1 (709) 123-5619', 2),
('John', 'Markston', '674 Lumbago Street', '2002-08-14', 'johnmarkston04@isp.ca', '1 (709) 123-7574', 1),
('Michael', 'Bell', '34 Snakeback Road', '1995-06-08', 'michaelbell05@isp.ca', '1 (709) 123-0445', 1),
('Wario', 'Waluinski', '13 Wario Street', '2000-03-21', 'wariowaluinski06@isp.ca', '1 (709) 123-1556', 2),
('Waluigi', 'Waluinski', '13 Wario Street', '2000-03-21', 'waluigiwaluinski07@isp.ca', '1 (709) 123-1895', 1),
('John', 'Money', '458 Country Road', '2002-08-14', 'johnmoney08@isp.ca', '1 (709) 123-4345', 1),
('Michael', 'McLaren', '19 This Street', '2001-08-23', 'michaelmclaren09@isp.ca', '1 (709) 123-3665', 2);

INSERT INTO course (courseName, semester, credit, lecture, labhours) VALUES

-- Electrical courses
('Oral Written Communication Skills', 5, 3, 3, 0),
('Project Management and Financial Analysis', 5, 4, 4, 0),
('Transformers', 5, 4, 3, 3),
('AC Machines', 5, 4, 3, 2),
('Advanced PLCs', 5, 4, 3, 3),
('Electrical Practices III', 5, 2, 1, 3),

-- Biomed courses
('Analog Electronics II', 5, 4, 3, 2),
('Network Fundamentals', 5, 4, 3, 3),
('Modulation and Encoding', 5, 5, 4, 2),
('Digital Systems II (Interfacing)', 5, 5, 4, 3),
('Advanced Circuit Analysis', 5, 5, 5, 0),

-- Electrical Prerequisites
('Technical Report Writing', 1, 3, 3, 0), 
('Advanced Mathematics', 2, 5, 5, 0), 
('Mathematics - Calculus', 4, 5, 5, 0), 
('DC Machines', 3, 4, 3, 2), 
('AC Circuits', 4, 4, 3, 3),
('Introduction to PLCs', 4, 4, 3, 3),
('AC Circuit Fundamentals', 2, 5, 4, 2),

-- Biomed Prerequisites
('Analog Electronics I', 4, 6, 5, 2),
('Signals & Measurements', 3, 3, 2, 2),
('Digital Systems I (Logic)', 4, 4, 3, 2),
('Applied Programming', 3, 4, 3, 2),
('Circuit Analysis I', 4, 4, 3, 2);

-- Add prerequisites

INSERT INTO course_prerequisite (courseID, prerequisiteID) VALUES
(2000, 2011),
(2001, 2012),
(2002, 2013),
(2002, 2015),
(2003, 2012),
(2003, 2017),
(2004, 2016),
(2006, 2018),
(2008, 2012),
(2008, 2019),
(2008, 2018),
(2009, 2020),
(2009, 2021),
(2010, 2013),
(2010, 2022);

-- Add Grades

INSERT INTO grades (studentID, courseID, grade) VALUES
(20100007, 2004, 83.33),
(20100004, 2004, 92.57);

-- Assign instructors to courses
INSERT INTO teaches (instructorID, courseID) VALUES
(10000001, 2008),
(10000001, 2007),
(10000000, 2003);


-- SQL Queries

-- Display all the students that are in the Biomedical program.
SELECT student.id, CONCAT(student.firstName, ' ', student.lastName) AS fullName
FROM student 
JOIN program ON student.programID = program.id
WHERE program.programName = 'Biomedical';


-- Display instructor's information and which courses they are teaching, if any.
SELECT instructor.id AS InstructorID, instructor.instructorName, instructor.email, instructor.phone, course.id AS CourseID, course.courseName
FROM instructor 
LEFT JOIN teaches ON instructor.id = teaches.instructorID
LEFT JOIN course ON teaches.courseID = course.id;


-- Display all courses offered and their prerequisites (if any).
SELECT course.id, course.courseName, course_prerequisite.prerequisiteID, prerequisite.courseName AS prerequisiteName
FROM course 
LEFT JOIN course_prerequisite ON course.id = course_prerequisite.courseID
LEFT JOIN course AS prerequisite ON course_prerequisite.prerequisiteID = prerequisite.id
ORDER BY course.id;


-- Display all students with the first name 'John'.
SELECT * FROM student
WHERE firstName = 'John';

-- Change Bobson Dugnutt's name while keeping the rest of his information the same.
UPDATE student
SET firstName = 'Lim', lastName = 'Jahey'
WHERE id = 20100000;

-- Update marks for students in Advanced PLCs to 0%.
UPDATE grades
SET grade = 0.00
WHERE courseID = 2004;

-- Display marks for students in Advanced PLCs.
SELECT grades.studentID, CONCAT(student.firstName, ' ', student.lastName) AS fullName, grades.grade
FROM grades 
JOIN student ON grades.studentID = student.id
WHERE grades.courseID = 2004;


-- Remove John Markston from Advanced PLCs.
DELETE FROM grades
WHERE studentID = 20100004
AND courseID = 2004;

-- Remove Michael Bell from the entire registration.
DELETE FROM student
WHERE id = 2010005;

-- Users

CREATE USER 'admin_user'@'localhost' IDENTIFIED BY 'admin_password';
GRANT ALL PRIVILEGES ON CP3520.* TO 'admin_user'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

CREATE USER 'student_user'@'localhost' IDENTIFIED BY 'student_password';
GRANT SELECT ON CP3520.student TO 'student_user'@'localhost';
GRANT SELECT ON CP3520.grades TO 'student_user'@'localhost';
GRANT SELECT ON CP3520.course TO 'student_user'@'localhost';
FLUSH PRIVILEGES;

CREATE USER 'teacher_user'@'localhost' IDENTIFIED BY 'teacher_password';
GRANT SELECT, INSERT, UPDATE ON CP3520.course TO 'teacher_user'@'localhost';
GRANT SELECT, INSERT, UPDATE ON CP3520.grades TO 'teacher_user'@'localhost';
GRANT SELECT, INSERT, UPDATE ON CP3520.student TO 'teacher_user'@'localhost';
GRANT SELECT ON CP3520.instructor TO 'teacher_user'@'localhost';
FLUSH PRIVILEGES;