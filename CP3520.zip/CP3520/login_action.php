<?php
session_start();
require 'db_connect.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password']; 
    $user_type = $_POST['user_type'];

    // Determine the appropriate table based on user type
    $table = '';
    $query = '';
    switch ($user_type) {
        case 'student':
            $table = 'student';
            $query = "SELECT id, CONCAT(firstName, ' ', lastName) AS fullName FROM $table WHERE id = :username AND id = :password"; 
            break;
        case 'admin':
            $table = 'administrator';
            $query = "SELECT id, adminName AS fullName FROM $table WHERE id = :username AND id = :password";
            break;
        default:
            header('Location: index.php?error=1');
            exit();
    }

    // Prepare and execute the query
    try {
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password); // Password is the same as ID
        $stmt->execute();

        // Check if a user was found
        if ($stmt->rowCount() == 1) {
            // Set session variables
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['username'] = $user['fullName']; // Store the user's name
            $_SESSION['user_type'] = $user_type;

            // Redirect to the appropriate dashboard
            switch ($user_type) {
                case 'student':
                    header('Location: student_dashboard.php');
                    exit();
                case 'admin':
                    header('Location: admin_dashboard.php');
                    exit();
            }
        } else {
            // If login fails, redirect back to login page with error
            header('Location: index.php?error=1');
            exit();
        }
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
}
?>
