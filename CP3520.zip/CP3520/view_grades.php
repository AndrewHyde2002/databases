<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['username']) || $_SESSION['user_type'] != 'student') {
    header('Location: index.php');
    exit();
}

// Assuming the student ID is stored as their username
$student_id = $_SESSION['username'];

try {
    // Adjust the query to use the existing course table structure
    $query = "
        SELECT course.courseName AS course_name, grades.grade 
        FROM grades 
        INNER JOIN course ON grades.courseID = course.id 
        WHERE grades.studentID = :student_id
    ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':student_id', $student_id, PDO::PARAM_INT);
    $stmt->execute();
    $grades = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error retrieving grades: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Grades</title>
</head>
<body>
    <h1>Your Grades</h1>

    <?php if (count($grades) > 0): ?>
        <table border="1">
            <tr>
                <th>Course Name</th>
                <th>Grade</th>
            </tr>
            <?php foreach ($grades as $grade): ?>
                <tr>
                    <td><?php echo htmlspecialchars($grade['course_name']); ?></td>
                    <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No grades found.</p>
    <?php endif; ?>

    <a href="student_dashboard.php" class="btn">Back to Dashboard</a>
</body>
</html>
