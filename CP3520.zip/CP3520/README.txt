Project created using XAMPP.

Student IDs start with 201000xx

Admin ID is 40000000

IDs and passwords are the same